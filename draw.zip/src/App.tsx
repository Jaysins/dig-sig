// src/App.tsx
import React from 'react';
import PdfEditor from './components/PdfViewer/PdfEditor';

const App: React.FC = () => {
  // Provide the URL of the PDF you want to display
  const pdfUrl = 'http://localhost:3000/CONTRACT AGREEMENT pdf.pdf';

  return (
      <div>
        <h1>PDF Editor</h1>
        <PdfEditor pdfUrl={pdfUrl} />
      </div>
  );
};

export default App;
