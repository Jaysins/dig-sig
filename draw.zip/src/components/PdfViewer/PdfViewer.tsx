import React, { useState, useRef } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import SignatureCanvas from 'react-signature-canvas';

const workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

// Specify the path to the PDF.js worker script
pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;

interface PdfViewerProps {
    pdfUrl: string;
}

const PdfViewer: React.FC<PdfViewerProps> = ({ pdfUrl }) => {
    const [error, setError] = useState<string | null>(null);
    const [numPages, setNumPages] = useState<number>(0);
    const signatureRef = useRef<SignatureCanvas | null>(null);

    const handleError = (e: Error) => {
        setError(e.message);
    };

    const handleLoadSuccess = ({ numPages }: { numPages: number }) => {
        setNumPages(numPages);
    };



    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            {error && <div>Error: {error}</div>}
            <Document file={pdfUrl} onLoadError={handleError} onLoadSuccess={handleLoadSuccess}>
                {[...Array(numPages)].map((_, index) => (
                    <div key={`page_${index + 1}`} style={{ position: 'relative' }}>
                        <Page pageNumber={index + 1} />
                        <SignatureCanvas
                            ref={signatureRef}
                            canvasProps={{ style: { position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' } }}
                        />
                    </div>
                ))}
            </Document>
        </div>
    );
};

export default PdfViewer;
